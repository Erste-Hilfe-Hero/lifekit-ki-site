
import * as React from 'react'
type Variant = 'default' | 'ghost' | 'outline'

export function Button({
  children,
  className = '',
  variant = 'default',
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  const base = 'inline-flex items-center justify-center px-3 py-2 rounded-xl text-sm font-medium transition border'
  const styles: Record<Variant, string> = {
    default: 'bg-zinc-900 text-white border-zinc-900 hover:opacity-90 dark:bg-white dark:text-zinc-900 dark:border-white',
    ghost: 'bg-transparent text-zinc-900 border-transparent hover:bg-zinc-100 dark:text-white dark:hover:bg-zinc-800',
    outline: 'bg-transparent text-zinc-900 border-zinc-300 hover:bg-zinc-50 dark:text-white dark:border-zinc-700 dark:hover:bg-zinc-900',
  }
  return (
    <button className={`${base} ${styles[variant]} ${className}`} {...props}>
      {children}
    </button>
  )
}
