
import React, { useEffect, useMemo, useRef, useState, createContext, useContext } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, HeartPulse, Hand, PhoneCall, Droplets, ShieldCheck, Info, Menu, X, Lightbulb, RefreshCw, Wand2, CheckCircle2, Shield, Brain, Settings, Save, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import ConsentBanner from "./Consent";

/**
 * LifeKit – Erste Hilfe & Notfall-Tools (mit KI-Assistent)
 * Monetarisierung: Platzhalter-Blöcke für Werbenetzwerke (Google AdSense, EthicalAds o.ä.)
 * Offline-first: funktioniert ohne Backend; optional BYOK (Bring Your Own Key) für LLM.
 *
 * WICHTIGER HINWEIS (rechtlich/medizinisch):
 * - Diese Seite ersetzt keine professionelle medizinische Beratung oder Schulung.
 * - Bei Notfällen sofort lokale Notrufnummer wählen (EU: 112).
 */

const classNames = (...arr: any[]) => arr.filter(Boolean).join(" ");

function useLocalStorage<T>(key: string, initial: T): [T, (v: any)=>void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  }, [key, value]);
  return [value, setValue as any];
}

// ---------- Ad-Slot (Platzhalter) ----------
function AdSlot({ id = "ad-1" }: { id?: string }) {
  return (
    <div
      id={id}
      className="w-full h-28 rounded-2xl border border-dashed border-zinc-300 dark:border-zinc-700 grid place-items-center text-zinc-500 text-sm bg-zinc-50 dark:bg-zinc-900"
      aria-label="Werbefläche"
    >
      <span>Werbefläche – hier Ad-Code einfügen (z.B. AdSense)</span>
    </div>
  );
}

// ---------- Content Store (überschreibbar + KI-änderbar) ----------
const defaultContent = {
  intro: {
    welcome: "Kostenlose Erste-Hilfe-Hinweise und praktische Tools, die offline funktionieren. Monetarisierung ausschließlich über Werbung – keine Paywalls, keine Logins.",
    bullets: [
      "DRSABCD-Karte & Notruf-Leitfaden",
      "CPR-Metronom (100–120 bpm)",
      "Rechner für Trinkwasserdesinfektion mit Haushaltsbleiche",
      "Handhygiene-Kurzleitfaden",
      "Bildschirm-Taschenlampe",
    ],
    disclaimer: "Diese Inhalte sind sorgfältig erstellt, ersetzen aber keine professionelle Schulung oder ärztliche Beratung. Bei Notfällen sofort den Notruf wählen (EU: 112).",
  },
  firstAid: {
    steps: [
      { title: "D – Danger / Gefahr prüfen", desc: "Eigene Sicherheit zuerst. Gefahr erkennen, sichern, Umfeld prüfen.", icon: "AlertTriangle" },
      { title: "R – Response / Reaktion prüfen", desc: "Laut ansprechen, sanft schütteln. Keine Reaktion? Hilfe rufen.", icon: "Hand" },
      { title: "S – Send for help / Hilfe rufen", desc: "Notruf wählen (EU: 112). Ort, Situation, Anzahl Betroffene, Zustand melden.", icon: "PhoneCall" },
      { title: "A – Airway / Atemweg freimachen", desc: "Kopf vorsichtig überstrecken, Mund prüfen, sichtbare Fremdkörper entfernen.", icon: "HeartPulse" },
      { title: "B – Breathing / Atmung prüfen", desc: "Sehen, hören, fühlen – max. 10 Sek. Keine normale Atmung? CPR starten.", icon: "HeartPulse" },
      { title: "C – CPR / Wiederbelebung", desc: "30:2 bei Erwachsenen (wenn möglich). Sonst kontinuierliche Kompressionen 100–120/min.", icon: "HeartPulse" },
      { title: "D – Defibrillation (AED)", desc: "AED holen lassen, einschalten, Anweisungen folgen so schnell wie möglich.", icon: "ShieldCheck" },
    ],
    wQuestions: ["Wo ist es passiert?", "Was ist passiert?", "Wie viele Betroffene?", "Welche Art von Verletzungen/Erkrankungen?", "Warten auf Rückfragen."],
  },
  cpr: {
    bullets: [
      "Bewusstsein prüfen, Notruf (112/911) veranlassen.",
      "Atmung prüfen – keine normale Atmung → sofort drücken.",
      "Harter Untergrund, Hände übereinander auf die Mitte des Brustkorbs.",
      "100–120 Kompressionen/Minute, Tiefe ~5–6 cm, vollständige Entlastung.",
      "Wenn möglich: Verhältnis 30:2 (2 Atemspenden nach 30 Kompressionen).",
      "AED so früh wie möglich einsetzen, Anweisungen folgen.",
    ],
  },
  water: {
    notes: [
      "Bevorzugt Wasser abkochen (1 Minute sprudelnd, ≥3 Minuten ab 2000 m Höhe).",
      "Duft-/farbfreie Haushaltsbleiche verwenden (Natriumhypochlorit). Nicht mit anderen Reinigern mischen!",
      "Nach dem Desinfizieren 30 Minuten warten; Wasser sollte leicht nach Chlor riechen.",
    ],
  },
  hygiene: {
    bullets: [
      "Hände 40–60 s waschen, alle Flächen (inkl. Daumen, Fingerspitzen)",
      "Wenn sichtbar sauber: Händedesinfektion 20–30 s",
      "Vor Essen, nach Toilette, nach Husten/Niesen, nach Kontakt mit Körperflüssigkeiten",
    ],
    sourceNote: "Basierend auf WHO-/CDC-Empfehlungen.",
  },
  emergencyNumbers: [
    { country: "EU (27) / EWR", numbers: ["112"], note: "Einheitliche EU-Notrufnummer" },
    { country: "Deutschland", numbers: ["112 (Feuer/Rettung)", "110 (Polizei)"] },
    { country: "Österreich", numbers: ["112", "133 Polizei", "144 Rettung", "122 Feuerwehr"] },
    { country: "Schweiz", numbers: ["112", "117 Polizei", "144 Sanität", "118 Feuerwehr"] },
    { country: "USA/Kanada", numbers: ["911"] },
    { country: "UK/Irland", numbers: ["999", "112"] },
  ],
};

const ContentContext = createContext<any>(null);
function useContent() { return useContext(ContentContext); }

// ---------- KI/Agent: Settings + Infrastruktur ----------
const defaultKISettings = {
  enabled: true,
  apiBase: "https://api.openai.com/v1/chat/completions",
  model: "gpt-4o-mini",
  apiKey: "",
  ownerPin: "0000",
  trustedSources: [
    "https://commission.europa.eu/live-work-travel-eu/consumer-rights-and-safety/make-your-home-and-life-safer/emergency-112_en",
    "https://www.resus.org.uk/library/2021-resuscitation-guidelines",
    "https://www.heart.org/en/",
    "https://www.cdc.gov/healthywater/emergency/index.html",
    "https://www.who.int/",
  ],
};

async function safeFetchText(url: string): Promise<string> {
  try {
    const proxied = url.startsWith("https://") ? url.replace("https://", "http://") : url;
    const r1 = await fetch(`https://r.jina.ai/http/${proxied.replace(/^https?:\\/\\//, "")}`);
    if (r1.ok) return await r1.text();
  } catch {}
  try {
    const r2 = await fetch(url as any, { mode: "cors" as any });
    if (r2.ok) return await r2.text();
  } catch {}
  return "";
}

async function callLLM({ apiBase, model, apiKey, system, user }: any) {
  if (!apiKey) throw new Error("Kein API-Key hinterlegt.");
  const res = await fetch(apiBase, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model, messages: [{ role: "system", content: system }, { role: "user", content: user }], temperature: 0.2 }),
  });
  const json = await res.json();
  if (!(res as any).ok) throw new Error(json?.error?.message || "LLM-Fehler");
  const txt = json.choices?.[0]?.message?.content?.trim?.() || "";
  return txt;
}

// ---------- CPR Metronom ----------
function Metronome({ defaultBpm = 110 }: { defaultBpm?: number }) {
  const [bpm, setBpm] = useState(defaultBpm);
  const [running, setRunning] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<number | null>(null);

  const click = () => {
    try {
      const AudioCtx: any = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!audioCtxRef.current) audioCtxRef.current = new AudioCtx();
      const ctx = audioCtxRef.current;
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine"; o.frequency.value = 880;
      g.gain.value = 0.0001;
      o.connect(g); g.connect(ctx.destination);
      o.start();
      g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.001);
      g.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + 0.08);
      o.stop(ctx.currentTime + 0.09);
    } catch {}
  };

  useEffect(() => {
    if (!running) return;
    click();
    const id = window.setInterval(click, 60000 / bpm);
    intervalRef.current = id;
    return () => { if (intervalRef.current) window.clearInterval(intervalRef.current); };
  }, [running, bpm]);

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><HeartPulse className="w-5 h-5"/> CPR Metronom (100–120 bpm)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <input type="range" min={100} max={120} value={bpm} onChange={(e)=>setBpm(parseInt((e.target as any).value))} className="w-full" aria-label="BPM-Regler" />
          <div className="min-w-16 text-center text-sm font-medium">{bpm} bpm</div>
        </div>
        <div className="flex gap-2">
          <Button onClick={()=>setRunning((v)=>!v)} className="rounded-2xl px-4">{running?"Stop":"Start"}</Button>
          <Button variant="outline" onClick={()=>setBpm(defaultBpm)} className="rounded-2xl">Reset</Button>
        </div>
        <p className="text-xs text-zinc-500">Hinweis: Richtwert gemäß Leitlinien – drücke fest und schnell in der Mitte des Brustkorbs, 30:2 Verhältnis bei erwachsenen Laienhelfern, wenn Beatmung möglich. Hole professionelle Hilfe so schnell wie möglich.</p>
      </CardContent>
    </Card>
  )
}

// ---------- Trinkwasser-Desinfektionsrechner ----------
const BLEACH_PROFILES = [
  { key: "5to9", label: "Bleiche 5–9% (Standard)", dropsPerGallon: 8, mlPerGallon: 0.5 },
  { key: "8_25", label: "Bleiche 8,25%", dropsPerGallon: 6, mlPerGallon: 0.375 },
  { key: "1pct", label: "Bleiche 1%", dropsPerLiter: 10, mlPerLiter: 0.5 },
];

function BleachCalculator() {
  const { content } = useContent();
  const [unit, setUnit] = useLocalStorage("lk_unit", "liter");
  const [amount, setAmount] = useLocalStorage("lk_amount", 5);
  const [profile, setProfile] = useLocalStorage("lk_profile", "5to9");
  const [cloudy, setCloudy] = useLocalStorage("lk_cloudy", false);

  const res = useMemo(()=>{
    const p: any = BLEACH_PROFILES.find(x=>x.key===profile) || BLEACH_PROFILES[0];
    const factor = cloudy ? 2 : 1;
    if (unit === "liter") {
      const liters = Number(amount)||0;
      if (p.dropsPerLiter != null) {
        const drops = p.dropsPerLiter * liters * factor;
        const ml = (p.mlPerLiter ?? (p.dropsPerLiter*0.005)) * liters * factor;
        return { drops, ml };
      } else {
        const gallons = liters / 3.78541;
        const drops = (p.dropsPerGallon * gallons) * factor;
        const ml = (p.mlPerGallon * gallons) * factor;
        return { drops, ml };
      }
    } else {
      const gallons = Number(amount)||0;
      if (p.dropsPerGallon != null) {
        const drops = p.dropsPerGallon * gallons * factor;
        const ml = (p.mlPerGallon * gallons) * factor;
        return { drops, ml };
      } else {
        const liters = gallons * 3.78541;
        const drops = (p.dropsPerLiter * liters) * factor;
        const ml = (p.mlPerLiter * liters) * factor;
        return { drops, ml };
      }
    }
  }, [unit, amount, profile, cloudy]);

  const pretty = (n: number) => {
    if (!isFinite(n)) return "–";
    if (n < 1) return n.toFixed(2);
    if (n < 10) return n.toFixed(1);
    return Math.round(n).toString();
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Droplets className="w-5 h-5"/> Trinkwasser-Desinfektionsrechner</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid md:grid-cols-4 gap-3">
          <div className="col-span-2">
            <label className="block text-sm mb-1">Menge</label>
            <input type="number" min={0} step="0.1" value={amount as any} onChange={(e)=>setAmount((e.target as any).value)} className="w-full px-3 py-2 rounded-xl border"/>
          </div>
          <div>
            <label className="block text-sm mb-1">Einheit</label>
            <select value={unit as any} onChange={(e)=>setUnit((e.target as any).value)} className="w-full px-3 py-2 rounded-xl border">
              <option value="liter">Liter</option>
              <option value="gallon">Gallonen</option>
            </select>
          </div>
          <div>
            <label className="block text-sm mb-1">Bleichmittel</label>
            <select value={profile as any} onChange={(e)=>setProfile((e.target as any).value)} className="w-full px-3 py-2 rounded-xl border">
              {BLEACH_PROFILES.map(p=> <option key={p.key} value={p.key}>{p.label}</option>)}
            </select>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <input id="lk_cloudy" type="checkbox" checked={cloudy as any} onChange={(e)=>setCloudy((e.target as any).checked)} />
          <label htmlFor="lk_cloudy" className="text-sm">Wasser ist trüb/ sehr kalt (Menge verdoppeln)</label>
        </div>

        <div className="grid md:grid-cols-3 gap-3">
          <div className="p-4 rounded-2xl bg-zinc-50 border">
            <div className="text-xs uppercase text-zinc-500">Ergebnis</div>
            <div className="text-3xl font-bold">{pretty((res as any).drops)}<span className="text-base font-medium"> Tropfen</span></div>
          </div>
          <div className="p-4 rounded-2xl bg-zinc-50 border">
            <div className="text-xs uppercase text-zinc-500">oder</div>
            <div className="text-3xl font-bold">{pretty((res as any).ml)}<span className="text-base font-medium"> mL</span></div>
          </div>
          <div className="p-4 rounded-2xl bg-zinc-50 border">
            <div className="text-xs uppercase text-zinc-500">Wartezeit</div>
            <div className="text-3xl font-bold">≥ 30<span className="text-base font-medium"> Minuten</span></div>
          </div>
        </div>
        <p className="text-xs text-zinc-500">Richtwerte für Notfälle. Wenn möglich: Wasser abkochen (bevorzugt). Nicht für chemisch kontaminiertes Wasser geeignet.</p>
      </CardContent>
    </Card>
  );
}

// ---------- DRSABCD / Erste Hilfe Basics ----------
function IconByName({ name, className }: { name: string, className?: string }) {
  const map: any = { AlertTriangle, Hand, PhoneCall, ShieldCheck, HeartPulse };
  const C = map[name] || Info;
  return <C className={className}/>;
}

function FirstAidBasics() {
  const { content } = useContent();
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><ShieldCheck className="w-5 h-5"/> Erste Hilfe – DRSABCD</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {content.firstAid.steps.map((s: any, i: number)=> (
            <div key={i} className="p-4 rounded-2xl border bg-white">
              <div className="flex items-center gap-2 mb-1">
                <IconByName name={s.icon} className="w-5 h-5"/>
                <div className="font-semibold">{s.title}</div>
              </div>
              <div className="text-sm text-zinc-600">{s.desc}</div>
            </div>
          ))}
        </div>
        <p className="text-xs text-zinc-500 mt-3">Hinweis: Diese Übersicht ersetzt keine Schulung. Lokale Leitlinien beachten.</p>
      </CardContent>
    </Card>
  );
}

// ---------- Handhygiene Infokarte ----------
function HandHygieneCard() {
  const { content } = useContent();
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Hand className="w-5 h-5"/> Handhygiene – Kurzleitfaden</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <ul className="list-disc pl-5 text-sm text-zinc-700">
          {content.hygiene.bullets.map((p: string, i: number)=>(<li key={i}>{p}</li>))}
        </ul>
        <div className="text-xs text-zinc-500">{content.hygiene.sourceNote}</div>
      </CardContent>
    </Card>
  )
}

// ---------- Notrufnummern ----------
function EmergencyNumbers() {
  const { content } = useContent();
  const [q, setQ] = useState("");
  const list = content.emergencyNumbers.filter((r: any) => r.country.toLowerCase().includes(q.toLowerCase()));
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><PhoneCall className="w-5 h-5"/> Wichtige Notrufnummern</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <input
          placeholder="Land suchen (z.B. Deutschland)"
          value={q}
          onChange={(e)=>setQ((e.target as any).value)}
          className="w-full px-3 py-2 rounded-xl border"
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {list.map((r: any, i: number)=> (
            <div key={i} className="p-4 rounded-2xl border bg-white">
              <div className="font-semibold">{r.country}</div>
              <div className="text-sm text-zinc-700">{r.numbers.join(" · ")}</div>
              {r.note && <div className="text-xs text-zinc-500 mt-1">{r.note}</div>}
            </div>
          ))}
        </div>
        <p className="text-xs text-zinc-500">EU-weit ist 112 kostenlos erreichbar – auch mobil.</p>
      </CardContent>
    </Card>
  );
}

// ---------- Bildschirm-Taschenlampe ----------
function ScreenFlashlight() {
  const [on, setOn] = useState(false);
  useEffect(()=>{
    (document.body as any).style.backgroundColor = on ? "#ffffe0" : "";
    return ()=>{ (document.body as any).style.backgroundColor = ""; };
  }, [on]);
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Lightbulb className="w-5 h-5"/> Bildschirm-Taschenlampe</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button onClick={()=>setOn(v=>!v)} className="rounded-2xl">{on?"Ausschalten":"Einschalten"}</Button>
        <p className="text-xs text-zinc-500">Erhöht die Bildschirmhelligkeit durch helle Fläche – nützlich, wenn kein Licht verfügbar ist.</p>
      </CardContent>
    </Card>
  );
}

// ---------- Feedback-Collector ----------
function FeedbackBox() {
  const [entries, setEntries] = useLocalStorage<any[]>("lk_feedback", []);
  const [text, setText] = useState("");
  const [rating, setRating] = useState(5);

  const add = () => {
    if (!text.trim()) return;
    const e = { id: Date.now(), rating, text, ua: navigator.userAgent, at: new Date().toISOString() };
    setEntries([e, ...entries].slice(0, 200));
    setText("");
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Wand2 className="w-5 h-5"/> Feedback</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <div className="grid md:grid-cols-4 gap-2">
          <div className="md:col-span-3">
            <Textarea value={text} onChange={(e)=>setText((e.target as any).value)} placeholder="Was war hilfreich? Was fehlt?" className="min-h-[80px]"/>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs">Bewertung (1–5)</label>
            <Input type="number" min={1} max={5} value={rating as any} onChange={(e)=>setRating(parseInt((e.target as any).value)||5)} />
            <Button onClick={add} className="rounded-2xl">Senden</Button>
          </div>
        </div>
        <div className="text-xs text-zinc-500">Datenschutz: Feedback wird lokal gespeichert. Optional kannst du in den KI‑Einstellungen eine Webhook‑URL setzen (deine Infrastruktur), um Feedback anonymisiert zu exportieren.</div>
      </CardContent>
    </Card>
  )
}

// ---------- KI-Agent Panel ----------
function KISettings({ settings, setSettings }: { settings: any, setSettings: (s:any)=>void }) {
  const [tmp, setTmp] = useState(settings);
  useEffect(()=>setTmp(settings), [settings]);
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Settings className="w-5 h-5"/> KI-Einstellungen (BYOK)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <label className="text-xs">API Base</label>
            <Input value={tmp.apiBase} onChange={(e)=>setTmp({...tmp, apiBase: (e.target as any).value})} />
          </div>
          <div>
            <label className="text-xs">Model</label>
            <Input value={tmp.model} onChange={(e)=>setTmp({...tmp, model: (e.target as any).value})} />
          </div>
          <div>
            <label className="text-xs">API Key</label>
            <Input type="password" value={tmp.apiKey} onChange={(e)=>setTmp({...tmp, apiKey: (e.target as any).value})} />
          </div>
          <div>
            <label className="text-xs">Owner PIN</label>
            <Input value={tmp.ownerPin} onChange={(e)=>setTmp({...tmp, ownerPin: (e.target as any).value})} />
          </div>
        </div>
        <div>
          <label className="text-xs">Vertrauensquellen (eine pro Zeile)</label>
          <Textarea value={tmp.trustedSources.join("\\n")} onChange={(e)=>setTmp({...tmp, trustedSources: (e.target as any).value.split(/\\n+/).map((s:string)=>s.trim()).filter(Boolean)})} />
        </div>
        <div className="flex gap-2">
          <Button onClick={()=>setSettings(tmp)} className="rounded-2xl"><Save className="w-4 h-4 mr-1"/> Speichern</Button>
        </div>
      </CardContent>
    </Card>
  );
}

function diffStrings(a: string, b: string) {
  const al = a.split(/\\r?\\n/), bl = b.split(/\\r?\\n/);
  const max = Math.max(al.length, bl.length);
  const rows: any[] = [];
  for (let i=0;i<max;i++) {
    const left = al[i] ?? "";
    const right = bl[i] ?? "";
    if (left !== right) rows.push({ i, left, right });
  }
  return rows;
}

function KIUpdater() {
  const { content, setContent } = useContent();
  const [settings, setSettings] = useLocalStorage("lk_ki_settings", defaultKISettings);
  const [status, setStatus] = useState("");
  const [sources, setSources] = useState<any[]>([]);
  const [proposals, setProposals] = useLocalStorage<any[]>("lk_ki_proposals", []);
  const [ownerPin, setOwnerPin] = useState("");

  const claims = [
    { id: "claim_112", text: "EU-Notruf 112 ist europaweit gültig", mustInclude: ["112", "EU"], weight: 1 },
    { id: "claim_cpr_rate", text: "CPR Kompressionsrate 100–120/min", mustInclude: ["100", "120", "compress"], weight: 1 },
    { id: "claim_cpr_30_2", text: "Erwachsene 30:2 wenn möglich", mustInclude: ["30", "2"], weight: 1 },
    { id: "claim_bleach_wait", text: "Nach Chlorierung ~30 Minuten warten", mustInclude: ["30", "minute"], weight: 0.5 },
  ];

  const checkSources = async () => {
    setStatus("Quellen werden geladen …");
    const out: any[] = [];
    for (const url of settings.trustedSources) {
      const txt = await safeFetchText(url);
      out.push({ url, ok: !!txt, len: txt.length, txt: txt.slice(0, 10000) });
    }
    setSources(out);
    setStatus(`Geladen: ${out.filter(o=>o.ok).length}/${out.length} Quellen`);
  };

  const verifyClaims = () => {
    const verdicts: Record<string, {hits:number, ok:boolean}> = {};
    for (const c of claims) {
      let hits = 0;
      for (const s of sources) {
        const t = (s.txt||"").toLowerCase();
        if (c.mustInclude.every(k => t.includes(k.toLowerCase()))) hits++;
      }
      verdicts[c.id] = { hits, ok: hits >= 2 };
    }
    return verdicts;
  };

  const proposeWithLLM = async () => {
    setStatus("LLM generiert Änderungsvorschläge …");
    const system = `Du bist ein fachlich korrekter Redakteur für eine Erste-Hilfe-WebApp. Du schlägst NUR präzise Textänderungen innerhalb eines JSON-Patch-Objekts vor. Ändere keine medizinischen Kernaussagen, wenn Vertrauens-Check < 2 Quellen.`;
    const user = JSON.stringify({
      currentContent: content,
      topFeedback: (JSON.parse(localStorage.getItem("lk_feedback")||"[]")).slice(0,20),
      factsProxySnippets: sources.map(s=>({ url: s.url, sample: (s.txt||'').slice(0,2000) })),
      goal: "Verbessere Verständlichkeit, Kürze wo sinnvoll, ergänze Quellenhinweise (ohne Links), vermeide Widersprüche."
    });
    try {
      const txt = await callLLM({ apiBase: settings.apiBase, model: settings.model, apiKey: settings.apiKey, system, user });
      let patch: any = {};
      try { patch = JSON.parse(txt); } catch {}
      if (!patch || typeof patch !== "object") throw new Error("Kein gültiges JSON erhalten.");
      setProposals([{ id: Date.now(), patch, createdAt: new Date().toISOString() }, ...proposals].slice(0,20));
      setStatus("Vorschlag erstellt.");
    } catch (e: any) {
      setStatus("Fehler: "+e.message);
    }
  };

  const applyPatch = (obj: any, patch: any) => {
    const recur = (t: any, p: any) => {
      const out = Array.isArray(t) ? [...t] : { ...t };
      for (const k of Object.keys(p)) {
        const pv = p[k];
        if (pv && typeof pv === "object" && !Array.isArray(pv) && typeof t?.[k] === "object") out[k] = recur(t[k], pv);
        else out[k] = pv;
      }
      return out;
    };
    return recur(obj, patch);
  };

  const publish = (p: any) => {
    if (ownerPin !== settings.ownerPin) { setStatus("Falscher PIN"); return; }
    const next = applyPatch(content, p.patch);
    setContent(next);
    setStatus("Änderungen veröffentlicht.");
  };

  const verdicts = verifyClaims();
  const trustOK = Object.values(verdicts).filter(v=>v.ok).length >= 2;

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Brain className="w-5 h-5"/> KI-Assistent (Beta) – Selbstverbesserung</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 text-sm">
        <div className="grid lg:grid-cols-2 gap-4">
          <KISettings settings={settings} setSettings={setSettings}/>
          <div className="p-4 rounded-2xl border bg-white">
            <div className="font-semibold mb-2 flex items-center gap-2"><Shield className="w-4 h-4"/> Vertrauens-Check</div>
            <div className="text-xs text-zinc-500 mb-2">Der Agent lädt Inhalte von definierten Vertrauensquellen und prüft Schlüsselbehauptungen per Heuristik.</div>
            <div className="flex gap-2 mb-2">
              <Button onClick={checkSources} className="rounded-2xl"><RefreshCw className="w-4 h-4 mr-1"/> Quellen prüfen</Button>
              <Button variant="outline" onClick={proposeWithLLM} className="rounded-2xl"><Wand2 className="w-4 h-4 mr-1"/> Entwurf erzeugen</Button>
            </div>
            <div className="space-y-2">
              {sources.map((s,i)=> (
                <div key={i} className="text-xs flex items-center gap-2">
                  <CheckCircle2 className={classNames("w-4 h-4", (s as any).ok?"text-emerald-600":"text-zinc-400")} />
                  <span className="truncate">{(s as any).url}</span>
                  <span className="text-zinc-400">({(s as any).len} Zeichen)</span>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <div className="font-semibold mb-1">Behauptungen</div>
              <ul className="text-xs list-disc pl-4">
                {claims.map(c=> (
                  <li key={c.id}>
                    {c.text} – {verdicts[c.id]?.ok?"bestätigt":"unsicher"} ({verdicts[c.id]?.hits||0} Quellen)
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl border bg-white">
          <div className="font-semibold mb-2 flex items-center gap-2"><UploadCloud className="w-4 h-4"/> Änderungsvorschläge</div>
          {(proposals as any[]).length===0 && <div className="text-xs text-zinc-500">Noch keine Vorschläge. Erzeuge einen mit dem LLM oder importiere manuell JSON.</div>}
          {(proposals as any[]).map(p=>{
            const before = JSON.stringify(content, null, 2);
            const after = JSON.stringify((()=>{
              const apply = (obj: any, patch: any) => {
                const recur = (t: any, p: any) => {
                  const out = Array.isArray(t) ? [...t] : { ...t };
                  for (const k of Object.keys(p)) {
                    const pv = p[k];
                    if (pv && typeof pv === "object" && !Array.isArray(pv) && typeof t?.[k] === "object") out[k] = recur(t[k], pv);
                    else out[k] = pv;
                  }
                  return out;
                };
                return recur(obj, patch);
              };
              return apply(content, (p as any).patch);
            })(), null, 2);
            const diffs = diffStrings(before, after);
            return (
              <div key={(p as any).id} className="mb-4 p-3 rounded-xl border">
                <div className="text-xs text-zinc-500">Erstellt: {new Date((p as any).createdAt).toLocaleString()}</div>
                <details className="mt-2">
                  <summary className="cursor-pointer text-sm">JSON‑Patch anzeigen</summary>
                  <pre className="mt-2 text-xs overflow-auto max-h-64 bg-zinc-50 p-2 rounded">{JSON.stringify((p as any).patch, null, 2)}</pre>
                </details>
                <details className="mt-2">
                  <summary className="cursor-pointer text-sm">Diff anzeigen ({diffs.length} Änderungen)</summary>
                  <div className="mt-2 max-h-64 overflow-auto text-xs">
                    {diffs.slice(0,300).map((d,i)=> (
                      <div key={i} className="grid grid-cols-2 gap-2 mb-1">
                        <div className="bg-red-50 p-1 rounded">{d.left}</div>
                        <div className="bg-emerald-50 p-1 rounded">{d.right}</div>
                      </div>
                    ))}
                  </div>
                </details>
                <div className="flex items-center gap-2 mt-3">
                  <Input placeholder="Owner PIN" value={ownerPin} onChange={(e)=>setOwnerPin((e.target as any).value)} className="max-w-40"/>
                  <Button disabled={!trustOK} onClick={()=>publish(p)} className="rounded-2xl">Veröffentlichen</Button>
                  {!trustOK && <span className="text-xs text-amber-600">Mind. 2 Kern-Behauptungen nicht bestätigt → Veröffentlichung gesperrt.</span>}
                </div>
              </div>
            );
          })}
        </div>

        <FeedbackBox/>

        <div className="text-xs text-zinc-500">Hinweis: Der KI‑Agent arbeitet clientseitig. Für LLM‑Funktionen ist ein eigener API‑Key erforderlich (wird nur lokal gespeichert). Medizinische Änderungen sollten zusätzlich von einer qualifizierten Person geprüft werden.</div>
        <div className="text-xs text-zinc-500">Status: {status}</div>
      </CardContent>
    </Card>
  );
}

// ---------- Haupt-App ----------
const TABS = [
  { key: "start", label: "Start" },
  { key: "erste-hilfe", label: "Erste Hilfe" },
  { key: "cpr", label: "CPR" },
  { key: "wasser", label: "Wasser" },
  { key: "hygiene", label: "Hygiene" },
  { key: "notruf", label: "Notruf" },
  { key: "ki", label: "KI" },
];

export default function App() {
  const [tab, setTab] = useLocalStorage("lk_tab", "start");
  const [menuOpen, setMenuOpen] = useState(false);
  const [content, setContent] = useLocalStorage("lk_content", defaultContent);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if ((e as any).key === "Escape") setMenuOpen(false); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <ContentContext.Provider value={{ content, setContent }}>
      <div className="min-h-screen bg-gradient-to-b from-white to-zinc-100 dark:from-zinc-950 dark:to-zinc-900 text-zinc-900 dark:text-zinc-50">
        <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/70 dark:supports-[backdrop-filter]:bg-zinc-900/60 border-b">
          <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-rose-500 grid place-items-center text-white font-bold">LK</div>
              <div>
                <div className="font-bold text-lg">LifeKit</div>
                <div className="text-xs text-zinc-500">Erste Hilfe & Notfall-Tools – ad-supported</div>
              </div>
            </div>
            <nav className="hidden md:flex items-center gap-1">
              {TABS.map(t => (
                <Button key={t.key} variant={tab===t.key?"default":"ghost"} onClick={()=>setTab(t.key)} className={classNames("rounded-2xl", tab===t.key && "bg-zinc-900 text-white dark:bg-white dark:text-zinc-900")}>{t.label}</Button>
              ))}
            </nav>
            <Button variant="ghost" className="md:hidden" onClick={()=>setMenuOpen(true)} aria-label="Menü öffnen"><Menu/></Button>
          </div>
          <AnimatePresence>
            {menuOpen && (
              <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/40" onClick={()=>setMenuOpen(false)}>
                <motion.div initial={{y:-20,opacity:0}} animate={{y:0,opacity:1}} exit={{y:-20,opacity:0}} className="absolute top-0 inset-x-0 bg-white dark:bg-zinc-900 border-b p-4">
                  <div className="flex items-center justify-between">
                    <div className="font-bold">Navigation</div>
                    <Button variant="ghost" onClick={()=>setMenuOpen(false)} aria-label="Menü schließen"><X/></Button>
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-2">
                    {TABS.map(t => (
                      <Button key={t.key} variant={tab===t.key?"default":"outline"} className="rounded-2xl" onClick={()=>{setTab(t.key); setMenuOpen(false);}}>{t.label}</Button>
                    ))}
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </header>

        <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
          <AdSlot id="ad-top" />

          {tab === "start" && (
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Info className="w-5 h-5"/> Willkommen bei LifeKit</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm text-zinc-700">
                    <p>{content.intro.welcome}</p>
                    <ul className="list-disc pl-5">
                      {content.intro.bullets.map((b,i)=> <li key={i}>{b}</li>)}
                    </ul>
                    <div className="p-3 rounded-xl bg-amber-50 text-amber-900 border text-xs">Disclaimer: {content.intro.disclaimer}</div>
                  </CardContent>
                </Card>
                <div className="grid sm:grid-cols-2 gap-6">
                  <FirstAidBasics/>
                  <HandHygieneCard/>
                </div>
              </div>
              <div className="space-y-6">
                <Metronome/>
                <ScreenFlashlight/>
              </div>
            </div>
          )}

          {tab === "erste-hilfe" && (
            <div className="space-y-6">
              <FirstAidBasics/>
              <AdSlot id="ad-mid-1"/>
              <div className="p-4 rounded-2xl border bg-white text-sm text-zinc-700">
                <div className="font-semibold mb-1">Notruf absetzen – 5 W-Fragen</div>
                <ol className="list-decimal pl-5 space-y-1">
                  {content.firstAid.wQuestions.map((w,i)=>(<li key={i}>{w}</li>))}
                </ol>
              </div>
            </div>
          )}

          {tab === "cpr" && (
            <div className="grid lg:grid-cols-2 gap-6">
              <Metronome/>
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle>CPR – Kurzanleitung (Erwachsene)</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-zinc-700">
                  <ol className="list-decimal pl-5 space-y-1">
                    {content.cpr.bullets.map((b,i)=>(<li key={i}>{b}</li>))}
                  </ol>
                  <div className="text-xs text-zinc-500">Orientierung an internationalen Leitlinien (AHA/ERC). Bei Kindern/Säuglingen gelten abweichende Regeln.</div>
                </CardContent>
              </Card>
            </div>
          )}

          {tab === "wasser" && (
            <div className="space-y-6">
              <BleachCalculator/>
              <AdSlot id="ad-mid-2"/>
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><Info className="w-5 h-5"/> Hinweise</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm text-zinc-700">
                  <ul className="list-disc pl-5">
                    {content.water.notes.map((n,i)=>(<li key={i}>{n}</li>))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          )}

          {tab === "hygiene" && (
            <div className="grid lg:grid-cols-2 gap-6">
              <HandHygieneCard/>
              <ScreenFlashlight/>
            </div>
          )}

          {tab === "notruf" && (
            <div className="space-y-6">
              <EmergencyNumbers/>
              <AdSlot id="ad-bottom"/>
            </div>
          )}

          {tab === "ki" && (
            <div className="space-y-6">
              <KIUpdater/>
            </div>
          )}

          <ConsentBanner/>

          <footer className="pt-8 border-t text-xs text-zinc-500">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
              <div>
                © {new Date().getFullYear()} LifeKit. Für die Menschheit kostenlos – finanziert durch Werbung.
              </div>
              <div className="flex items-center gap-3">
                <a className="underline" href="/impressum.html">Impressum</a>
                <a className="underline" href="/datenschutz.html">Datenschutz</a>
              </div>
            </div>
          </footer>
        </main>
      </div>
    </ContentContext.Provider>
  );
}
