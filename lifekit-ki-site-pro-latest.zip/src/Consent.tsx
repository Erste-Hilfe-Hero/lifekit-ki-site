
import React from 'react'
import { Button } from '@/components/ui/button'

export function useConsent() {
  const [consent, setConsent] = React.useState<string | null>(() => localStorage.getItem('consent'));
  const accept = (v: 'all' | 'essentials') => { localStorage.setItem('consent', v); setConsent(v); };
  const revoke = () => { localStorage.removeItem('consent'); setConsent(null); };
  return { consent, accept, revoke };
}

export default function ConsentBanner() {
  const { consent, accept } = useConsent();
  if (consent) return null;
  return (
    <div className="fixed inset-x-0 bottom-0 z-50">
      <div className="mx-auto max-w-4xl m-3 p-4 rounded-2xl border bg-white/90 backdrop-blur text-sm">
        <div className="font-semibold mb-1">Cookies & Werbung</div>
        <p className="text-zinc-600 mb-3">Wir verwenden essenzielle Cookies. Werbung kann zusätzliche Cookies verwenden. Du kannst nur essenzielle Cookies akzeptieren oder alles erlauben.</p>
        <div className="flex gap-2">
          <Button variant="outline" onClick={()=>accept('essentials')}>Nur essenzielle</Button>
          <Button onClick={()=>accept('all')}>Alles erlauben</Button>
        </div>
      </div>
    </div>
  );
}
